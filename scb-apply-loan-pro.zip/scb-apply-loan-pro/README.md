# SCB Apply Loan — Detailed React Clone (CRA)

This project recreates a detailed multi-step **Home Loan** application flow in React (Create React App, no Vite). It mirrors the structure and fields typically requested on Standard Chartered India’s online home-loan intake, with a similar blue/green visual style.

## Run locally

```bash
cd scb-apply-loan-pro
npm install
npm start
```

## Steps
1. Welcome
2. Personal Details
3. Contact & Address
4. Employment
5. Income & Obligations
6. Property Details
7. Loan Requirements
8. Declarations
9. Review & Submit → Success (reference + “2–3 business days”)
