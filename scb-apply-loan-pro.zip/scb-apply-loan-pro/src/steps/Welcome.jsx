import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Welcome(){
  const navigate = useNavigate();
  return (
    <section>
      <p>Quick online application. It takes just a few minutes.</p>
      <div className="actions" style={{justifyContent:'flex-start'}}>
        <button className="btn" onClick={() => navigate('/personal')}>Start Application</button>
      </div>
    </section>
  );
}