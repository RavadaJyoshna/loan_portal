import React from 'react';
import { FormContext } from '../components/Wizard';

export default function Income(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  return (
    <form onSubmit={e => {e.preventDefault(); next();}} noValidate>
      <section className="grid two-col gap">
        <Field label="Monthly income (₹)" error={errors.monthlyIncome}>
          <input inputMode="numeric" value={data.monthlyIncome} onChange={e=>update('monthlyIncome', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Other income (₹)">
          <input inputMode="numeric" value={data.otherIncome} onChange={e=>update('otherIncome', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Existing EMIs?">
          <select value={data.existingEmi} onChange={e=>update('existingEmi', e.target.value)}>
            <option value="">Select</option>
            <option value="no">No</option>
            <option value="yes">Yes</option>
          </select>
        </Field>
        {data.existingEmi === 'yes' && (
          <Field label="Total EMI amount (₹)" error={errors.existingEmiAmt}>
            <input inputMode="numeric" value={data.existingEmiAmt} onChange={e=>update('existingEmiAmt', e.target.value.replace(/\D/g,''))} />
          </Field>
        )}
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Next</button>
      </div>
    </form>
  );
}

function Field({label, error, children}){
  return <label className={"field "+(error?'invalid':'')}><span className="label">{label}</span>{children}{error && <span className="error">{error}</span>}</label>
}
