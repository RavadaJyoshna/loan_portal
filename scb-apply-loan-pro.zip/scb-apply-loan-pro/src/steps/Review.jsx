import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FormContext } from '../components/Wizard';

export default function Review(){
  const {data} = React.useContext(FormContext);
  const navigate = useNavigate();

  function submit(){
    // simulate submit and route to success
    setTimeout(() => navigate('/success'), 500);
  }

  const rows = Object.entries(data);

  return (
    <section>
      <h2>Review your details</h2>
      <div className="review">
        {rows.map(([k,v]) => (
          <div key={k} className="review-row">
            <div className="review-key">{labelize(k)}</div>
            <div className="review-val">{String(v || '-')}</div>
          </div>
        ))}
      </div>
      <div className="actions">
        <button className="btn" onClick={submit}>Apply Now</button>
      </div>
    </section>
  );
}

function labelize(key){
  return key.replace(/([A-Z])/g,' $1').replace(/^./, s=>s.toUpperCase());
}
