import React from 'react';
import { FormContext } from '../components/Wizard';
import { useNavigate } from 'react-router-dom';

export default function Declarations(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  const navigate = useNavigate();
  function toReview(e){
    e.preventDefault();
    if (next) next();
    navigate('/review');
  }
  return (
    <form onSubmit={toReview} noValidate>
      <section className="grid gap">
        <label className={"check " + (errors.agree ? 'invalid' : '')}>
          <input type="checkbox" checked={data.agree} onChange={e=>update('agree', e.target.checked)} />
          I confirm that the information provided is true and accurate.
        </label>
        <label className="check">
          <input type="checkbox" checked={data.consentKyc} onChange={e=>update('consentKyc', e.target.checked)} />
          I consent to verification of my KYC details, credit bureau checks and other validations for processing this application.
        </label>
        <label className="check">
          <input type="checkbox" checked={data.consentContact} onChange={e=>update('consentContact', e.target.checked)} />
          I agree to be contacted via phone, SMS or email regarding this application.
        </label>
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Review</button>
      </div>
    </form>
  );
}
