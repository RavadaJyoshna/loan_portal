import React from 'react';
import { FormContext } from '../components/Wizard';

export default function Contact(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  return (
    <form onSubmit={e => {e.preventDefault(); next();}} noValidate>
      <section className="grid two-col gap">
        <Field label="Email" error={errors.email}>
          <input type="email" value={data.email} onChange={e=>update('email', e.target.value)} />
        </Field>
        <Field label="Mobile number" error={errors.mobile}>
          <input inputMode="numeric" maxLength={10} value={data.mobile} onChange={e=>update('mobile', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Alternate mobile">
          <input inputMode="numeric" maxLength={10} value={data.altMobile} onChange={e=>update('altMobile', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Residence type">
          <select value={data.residenceType} onChange={e=>update('residenceType', e.target.value)}>
            <option value="">Select</option>
            <option>Owned</option><option>Rented</option><option>Parental</option><option>Company Provided</option>
          </select>
        </Field>
        <Field label="Current address" error={errors.currentAddress}>
          <input value={data.currentAddress} onChange={e=>update('currentAddress', e.target.value)} />
        </Field>
        <Field label="City" error={errors.city}>
          <input value={data.city} onChange={e=>update('city', e.target.value)} />
        </Field>
        <Field label="State" error={errors.state}>
          <input value={data.state} onChange={e=>update('state', e.target.value)} />
        </Field>
        <Field label="PIN code" error={errors.pincode}>
          <input inputMode="numeric" maxLength={6} value={data.pincode} onChange={e=>update('pincode', e.target.value.replace(/\D/g,''))} />
        </Field>
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Next</button>
      </div>
    </form>
  );
}

function Field({label, error, children}){
  return <label className={"field "+(error?'invalid':'')}><span className="label">{label}</span>{children}{error && <span className="error">{error}</span>}</label>
}
