import React from 'react';
import { FormContext } from '../components/Wizard';

export default function Property(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  return (
    <form onSubmit={e => {e.preventDefault(); next();}} noValidate>
      <section className="grid two-col gap">
        <Field label="Property city" error={errors.propertyCity}>
          <input value={data.propertyCity} onChange={e=>update('propertyCity', e.target.value)} />
        </Field>
        <Field label="Property type" error={errors.propertyType}>
          <select value={data.propertyType} onChange={e=>update('propertyType', e.target.value)}>
            <option value="">Select</option>
            <option>Apartment</option><option>Independent house</option><option>Plot</option>
          </select>
        </Field>
        <Field label="Purpose" error={errors.propertyPurpose}>
          <select value={data.propertyPurpose} onChange={e=>update('propertyPurpose', e.target.value)}>
            <option value="">Select</option>
            <option value="purchase">Purchase</option>
            <option value="construction">Construction</option>
            <option value="renovation">Renovation</option>
            <option value="balance-transfer">Balance Transfer</option>
          </select>
        </Field>
        <Field label="Builder / Project">
          <input value={data.builder} onChange={e=>update('builder', e.target.value)} />
        </Field>
        <Field label="Property value (₹)" error={errors.propertyValue}>
          <input inputMode="numeric" value={data.propertyValue} onChange={e=>update('propertyValue', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Down payment (₹)">
          <input inputMode="numeric" value={data.downPayment} onChange={e=>update('downPayment', e.target.value.replace(/\D/g,''))} />
        </Field>
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Next</button>
      </div>
    </form>
  );
}

function Field({label, error, children}){
  return <label className={"field "+(error?'invalid':'')}><span className="label">{label}</span>{children}{error && <span className="error">{error}</span>}</label>
}
