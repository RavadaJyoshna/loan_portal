import React from 'react';
import { FormContext } from '../components/Wizard';
import { useNavigate } from 'react-router-dom';

export default function LoanDetails(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  return (
    <form onSubmit={e => {e.preventDefault(); next();}} noValidate>
      <section className="grid two-col gap">
        <Field label="Desired loan amount (₹)" error={errors.loanAmount}>
          <input inputMode="numeric" value={data.loanAmount} onChange={e=>update('loanAmount', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Tenure" error={errors.tenure}>
          <select value={data.tenure} onChange={e=>update('tenure', e.target.value)}>
            <option value="">Select</option>
            <option value="5">5 years</option><option value="10">10 years</option>
            <option value="15">15 years</option><option value="20">20 years</option>
            <option value="25">25 years</option><option value="30">30 years</option>
          </select>
        </Field>
        <Field label="Balance transfer outstanding (₹)">
          <input inputMode="numeric" value={data.btOutstanding} onChange={e=>update('btOutstanding', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Existing lender (if BT)">
          <input value={data.btBank} onChange={e=>update('btBank', e.target.value)} />
        </Field>
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Next</button>
      </div>
    </form>
  );
}

function Field({label, error, children}){
  return <label className={"field "+(error?'invalid':'')}><span className="label">{label}</span>{children}{error && <span className="error">{error}</span>}</label>
}
