import React from 'react';
import { FormContext } from '../components/Wizard';

export default function Employment(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  return (
    <form onSubmit={e => {e.preventDefault(); next();}} noValidate>
      <section className="grid two-col gap">
        <Field label="Employment type" error={errors.employmentType}>
          <select value={data.employmentType} onChange={e=>update('employmentType', e.target.value)}>
            <option value="">Select</option>
            <option value="salaried">Salaried</option>
            <option value="self-employed">Self-employed</option>
            <option value="professional">Professional</option>
            <option value="retired">Retired</option>
          </select>
        </Field>
        <Field label="Company / Business name" error={errors.company}>
          <input value={data.company} onChange={e=>update('company', e.target.value)} />
        </Field>
        <Field label="Designation" error={errors.designation}>
          <input value={data.designation} onChange={e=>update('designation', e.target.value)} />
        </Field>
        <Field label="Work email">
          <input type="email" value={data.workEmail} onChange={e=>update('workEmail', e.target.value)} />
        </Field>
        <Field label="Work phone">
          <input inputMode="numeric" value={data.workPhone} onChange={e=>update('workPhone', e.target.value.replace(/\D/g,''))} />
        </Field>
        <Field label="Total experience (years)">
          <input inputMode="numeric" value={data.totalExp} onChange={e=>update('totalExp', e.target.value.replace(/\D/g,''))} />
        </Field>
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Next</button>
      </div>
    </form>
  );
}

function Field({label, error, children}){
  return <label className={"field "+(error?'invalid':'')}><span className="label">{label}</span>{children}{error && <span className="error">{error}</span>}</label>
}
