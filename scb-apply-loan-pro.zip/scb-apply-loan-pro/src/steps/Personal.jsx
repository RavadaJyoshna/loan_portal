import React from 'react';
import { FormContext } from '../components/Wizard';

export default function Personal(){
  const {data, update, errors, next, back} = React.useContext(FormContext);
  return (
    <form onSubmit={e => {e.preventDefault(); next();}} noValidate>
      <section className="grid two-col gap">
        <Field label="Title">
          <select value={data.title} onChange={e=>update('title', e.target.value)}>
            <option value="">Select</option>
            <option>Mr</option><option>Ms</option><option>Mrs</option><option>Dr</option>
          </select>
        </Field>
        <Field label="Gender">
          <select value={data.gender} onChange={e=>update('gender', e.target.value)}>
            <option value="">Select</option>
            <option>Male</option><option>Female</option><option>Other</option>
          </select>
        </Field>
        <Field label="First name" error={errors.firstName}>
          <input value={data.firstName} onChange={e=>update('firstName', e.target.value)} />
        </Field>
        <Field label="Last name" error={errors.lastName}>
          <input value={data.lastName} onChange={e=>update('lastName', e.target.value)} />
        </Field>
        <Field label="Date of birth" error={errors.dob}>
          <input type="date" value={data.dob} onChange={e=>update('dob', e.target.value)} />
        </Field>
        <Field label="Marital status">
          <select value={data.maritalStatus} onChange={e=>update('maritalStatus', e.target.value)}>
            <option value="">Select</option>
            <option>Single</option><option>Married</option><option>Divorced</option><option>Widowed</option>
          </select>
        </Field>
        <Field label="PAN" error={errors.pan}>
          <input value={data.pan} onChange={e=>update('pan', e.target.value.toUpperCase())} placeholder="ABCDE1234F" maxLength={10}/>
        </Field>
      </section>
      <div className="actions">
        <button type="button" className="btn btn-ghost" onClick={back}>Back</button>
        <button className="btn">Next</button>
      </div>
    </form>
  );
}

function Field({label, error, children}){
  return <label className={"field "+(error?'invalid':'')}><span className="label">{label}</span>{children}{error && <span className="error">{error}</span>}</label>
}
