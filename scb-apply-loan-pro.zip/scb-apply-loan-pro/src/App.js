import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Success from './components/Success';
import Wizard from './components/Wizard';
import Review from './steps/Review';
import Welcome from './steps/Welcome';
import Personal from './steps/Personal';
import Contact from './steps/Contact';
import Employment from './steps/Employment';
import Income from './steps/Income';
import Property from './steps/Property';
import LoanDetails from './steps/LoanDetails';
import Declarations from './steps/Declarations';

export default function App(){
  return (
    <div className="app-shell">
      <Header />
      <Routes>
        <Route path="/" element={<Wizard />}>
          <Route index element={<Welcome />} />
          <Route path="personal" element={<Personal />} />
          <Route path="contact" element={<Contact />} />
          <Route path="employment" element={<Employment />} />
          <Route path="income" element={<Income />} />
          <Route path="property" element={<Property />} />
          <Route path="loan" element={<LoanDetails />} />
          <Route path="declarations" element={<Declarations />} />
          <Route path="review" element={<Review />} />
        </Route>
        <Route path="/success" element={<Success />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Footer />
    </div>
  );
}
