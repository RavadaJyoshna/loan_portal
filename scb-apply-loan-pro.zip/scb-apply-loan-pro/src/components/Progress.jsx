import React from 'react';
export default function Progress({items, current}){
  const idx = items.findIndex(i => i.path === current);
  const pct = Math.round(((idx+1)/items.length)*100);
  return (
    <div className="progress-wrap" aria-label="Progress">
      <div className="progress-track">
        <div className="progress-fill" style={{width: pct + '%'}} />
      </div>
      <div className="progress-legend">{items[idx]?.label} — Step {idx+1} of {items.length}</div>
    </div>
  );
}