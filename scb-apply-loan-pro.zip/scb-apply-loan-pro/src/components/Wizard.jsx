import React from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import Progress from './Progress';

export const steps = [
  { path: '/', label: 'Welcome' },
  { path: '/personal', label: 'Personal Details' },
  { path: '/contact', label: 'Contact & Address' },
  { path: '/employment', label: 'Employment' },
  { path: '/income', label: 'Income & Obligations' },
  { path: '/property', label: 'Property Details' },
  { path: '/loan', label: 'Loan Requirements' },
  { path: '/declarations', label: 'Declarations' },
  { path: '/review', label: 'Review & Submit' },
];

export const FormContext = React.createContext(null);

export default function Wizard(){
  const navigate = useNavigate();
  const location = useLocation();
  const [data, setData] = React.useState({
    // personal
    title:'', firstName:'', lastName:'', dob:'', gender:'', maritalStatus:'', pan:'',
    // contact
    email:'', mobile:'', altMobile:'', residenceType:'', currentAddress:'', city:'', state:'', pincode:'',
    // employment
    employmentType:'', company:'', designation:'', workEmail:'', workPhone:'', totalExp:'',
    // income
    monthlyIncome:'', otherIncome:'', existingEmi:'', existingEmiAmt:'',
    // property
    propertyCity:'', propertyType:'', propertyPurpose:'', builder:'', propertyValue:'', downPayment:'',
    // loan
    loanAmount:'', tenure:'', btOutstanding:'', btBank:'',
    // declarations
    consentKyc:false, consentContact:false, agree:true
  });
  const [errors, setErrors] = React.useState({});

  const current = steps.find(s => location.pathname === s.path) ? location.pathname : '/';

  function update(field, value){ setData(prev => ({...prev, [field]: value})); }

  function validate(path=current){
    const e = {};
    const isEmail = v => /\S+@\S+\.\S+/.test(v);
    const isPhone = v => /^\d{10}$/.test(v);
    const isPAN = v => /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(v);

    if (path === '/personal'){
      if (!data.firstName) e.firstName = 'Required';
      if (!data.lastName) e.lastName = 'Required';
      if (!data.dob) e.dob = 'Required';
      if (data.pan && !isPAN(data.pan)) e.pan = 'Invalid PAN (e.g., ABCDE1234F)';
    }
    if (path === '/contact'){
      if (!isEmail(data.email)) e.email = 'Valid email required';
      if (!isPhone(data.mobile)) e.mobile = '10-digit mobile required';
      if (!data.city) e.city = 'Required';
      if (!/^\d{6}$/.test(data.pincode)) e.pincode = '6-digit PIN required';
      if (!data.currentAddress) e.currentAddress = 'Required';
      if (!data.state) e.state = 'Required';
    }
    if (path === '/employment'){
      if (!data.employmentType) e.employmentType = 'Required';
      if (!data.company) e.company = 'Required';
      if (!data.designation) e.designation = 'Required';
    }
    if (path === '/income'){
      if (!data.monthlyIncome || Number(data.monthlyIncome) < 10000) e.monthlyIncome = 'Enter valid income';
      if (data.existingEmi === 'yes' && (!data.existingEmiAmt || Number(data.existingEmiAmt) <= 0)) e.existingEmiAmt = 'Enter EMI amount';
    }
    if (path === '/property'){
      if (!data.propertyCity) e.propertyCity = 'Required';
      if (!data.propertyType) e.propertyType = 'Required';
      if (!data.propertyPurpose) e.propertyPurpose = 'Required';
      if (!data.propertyValue || Number(data.propertyValue) < 1000000) e.propertyValue = 'Min ₹10,00,000';
    }
    if (path === '/loan'){
      if (!data.loanAmount || Number(data.loanAmount) < 1000000) e.loanAmount = 'Min ₹10,00,000';
      if (!data.tenure) e.tenure = 'Required';
      if (data.propertyPurpose === 'balance-transfer' && (!data.btOutstanding || !data.btBank)) {
        e.btOutstanding = 'Outstanding required';
        e.btBank = 'Bank required';
      }
    }
    if (path === '/declarations'){
      if (!data.agree) e.agree = 'You must agree to proceed';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function next(){
    const idx = steps.findIndex(s => s.path === current);
    if (idx < 0) return;
    if (!validate(current)) return;
    const nxt = steps[Math.min(idx+1, steps.length-1)].path;
    navigate(nxt);
  }

  function back(){
    const idx = steps.findIndex(s => s.path === current);
    if (idx <= 0) return;
    navigate(steps[idx-1].path);
  }

  return (
    <main className="container content">
      <div className="hero">
        <h1 className="hero-title">Apply for a Home Loan</h1>
        <p className="hero-subtitle">Fill in your details to get started.</p>
      </div>

      <div className="card">
        <Progress items={steps} current={current} />
        <FormContext.Provider value={{data, update, errors, validate, next, back}}>
          <Outlet />
        </FormContext.Provider>
      </div>
    </main>
  );
}
