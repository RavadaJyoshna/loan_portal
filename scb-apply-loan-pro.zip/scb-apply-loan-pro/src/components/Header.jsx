import React from 'react';
import { Link } from 'react-router-dom';

export default function Header(){
  return (
    <header className="header">
      <div className="header-inner container">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true" />
          <span className="brand-name">Standard Chartered — Demo</span>
        </div>
        <nav className="nav">
          <Link to="/" className="nav-link">Home Loan</Link>
          <a href="#" className="nav-link">Eligibility</a>
          <a href="#" className="nav-link">Rates</a>
          <a href="#" className="nav-link">Help</a>
        </nav>
      </div>
    </header>
  );
}
