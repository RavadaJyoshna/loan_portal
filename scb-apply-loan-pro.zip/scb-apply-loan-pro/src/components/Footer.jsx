import React from 'react';

export default function Footer(){
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <small>© {new Date().getFullYear()} Demo project for educational use only.</small>
        <div className="legal-links">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">Disclosures</a>
        </div>
      </div>
    </footer>
  );
}
