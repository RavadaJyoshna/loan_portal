import React from 'react';
import { Link } from 'react-router-dom';

export default function Success(){
  const ref = React.useMemo(() => 'HL-' + Math.random().toString(36).slice(2,8).toUpperCase(), []);
  return (
    <main className="container content">
      <div className="card success-card">
        <div className="success-icon" aria-hidden="true">✓</div>
        <h1>Application submitted</h1>
        <p>Your reference number is <strong>{ref}</strong>.</p>
        <p>We’ll contact you within <strong>2–3 business days</strong>.</p>
        <div className="actions">
          <Link to="/" className="btn btn-outline">Back to start</Link>
        </div>
      </div>
    </main>
  );
}
